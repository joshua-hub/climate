/*******************************************************************************
  PHYS3071 (and PHYS7073) Lecture Week 8 Baumgardt 0123456
 
  Program climate change (c) copyleft Holger Baumgardt 2014

  Verbatim copying and distribution of this entire program
  is permitted in any medium, provided this notice is preserved.
 
  About: This program fits a straight line to the climate data 
 
  Compile: gcc -Wall -lm as08_climatechange.c -o as08_climatechange 
 
  Input: The name of the file with the climate data and the range of years for
         which the fit should be made 
 
  Output: The values of the best-fitting parameters a and b
          The predicted mean temperature in the years 2050 and 2100
          The five hottest months  
***********************80*character*limit*good*for* a2ps***********************/
#include<stdio.h>
#include<stdlib.h>
#include<strings.h>
#include<math.h>


#define NDATAMAX  10000

// Function that calculates the best fit
void climatefit(double starty, double endy, int nlines, double date[], double temp[], double etemp[], double *a, double *b, double *e) {
  int i,ndata=0;
  double sume2=0.0,sumxye2=0.0,sumxe2=0.0,sumye2=0.0,sumx2e2=0.0;

  for (i=0;i<nlines;i++) {
    if (date[i]>starty && date[i]<endy+1.0) {
      sume2   += 1.0/(etemp[i]*etemp[i]);
      sumxye2 += date[i]*temp[i]/(etemp[i]*etemp[i]);
      sumxe2  += date[i]/(etemp[i]*etemp[i]);
      sumye2  += temp[i]/(etemp[i]*etemp[i]);
      sumx2e2 += date[i]*date[i]/(etemp[i]*etemp[i]);
    }
  }

  *a = (sume2*sumxye2-sumxe2*sumye2)/(sume2*sumx2e2-sumxe2*sumxe2);
  *b = (sumye2-*a*sumxe2)/sume2;

  for (i=0;i<nlines;i++) 
    if (date[i]>starty && date[i]<endy+1.0)  {
      *e += pow((temp[i]-(*a*date[i]+*b))/etemp[i],2.0);
      ndata++;
    }

  *e /= (1.0*ndata);
}


  

int main() {
 char *fname;
 FILE *dat;
 double starty,endy;  // Start and end year
 double *temp,*etemp,*date;
 int iyear,month,nlines=0;
 int i,k,itmax;
 double a,b,e; 

 fname = malloc(100*sizeof(char));

 temp  = malloc(NDATAMAX*sizeof(double));
 etemp = malloc(NDATAMAX*sizeof(double));
 date  = malloc(NDATAMAX*sizeof(double));

 printf("This program determines the best-fitting line to the global temperatures\n");

// Read in file name, start & end year
 printf("\nEnter the name of the climate data file: "); 
 fgets(fname,100,stdin);
 fname[strlen(fname)-1]=0;

 printf("\nEnter the start year: ");
 scanf("%lf",&starty);

 printf("\nEnter the end year: ");
 scanf("%lf",&endy);

// Check validity of user input
 if (endy<starty) {
    printf("Error: Start year has to be smaller than end year !\n");
    exit(-1);
 }

 if ((dat=fopen(fname,"r"))==NULL) {
   printf("\nOpening failed\n"); 
   exit(-1);
 } else {
   while (fscanf(dat,"%i %i %lf %lf", &iyear,&month,(temp+nlines),(etemp+nlines))!=EOF) {
     date[nlines] = iyear+(month-0.5)/12.0;
     nlines++;
     if (nlines>NDATAMAX) {
       printf("Error: Climate file contains too many lines !\n");
       exit(-1);
     }
   }
 }

 printf("Read %i lines from the climate file !\n",nlines);

 climatefit (starty,endy,nlines,date,temp,etemp,&a,&b,&e);

 printf("The best fitting values for a and b are:  a = %lf  b = %lf\n",a,b);

 printf("The weighted error is:  e = %lf\n",e);

 printf("Predicted mean temperature in the year 2050: %lf\n",a*2050.0+b);
 printf("Predicted mean temperature in the year 2100: %lf\n",a*2100.0+b);

 printf("The five hottest months and corresponding temperatures are:\n ");
 for (k=0;k<5;k++) {
   itmax=0;
   for (i=1;i<nlines;i++) 
     if (*(temp+i)>*(temp+itmax)) itmax=i;
   printf("%7.2lf  +%lf degrees ---- ",*(date+itmax),*(temp+itmax)); 
   *(temp+itmax)=-999.9;
 }

 printf("\n\n");
 exit(0);
}
